﻿namespace Vehicles.IO
{
    public interface IReader
    {
        string ReadLine();
    }
}
