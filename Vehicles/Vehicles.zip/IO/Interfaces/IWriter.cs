﻿namespace Vehicles.IO
{
    public interface IWriter
    {
        void WriteLine(string str);
    }
}
